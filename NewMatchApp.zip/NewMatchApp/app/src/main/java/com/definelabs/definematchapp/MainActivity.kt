package com.definelabs.definematchapp

import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var toolbar: Toolbar
    private lateinit var navigationView: NavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d("MainActivity", "Activity Created")

        drawerLayout = findViewById(R.id.drawer_layout)
        toolbar = findViewById(R.id.toolbar)
        navigationView = findViewById(R.id.navigation_view)

        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(android.R.drawable.ic_menu_sort_by_size)

        val drawerToggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, R.string.open_drawer, R.string.close_drawer
        )
        drawerLayout.addDrawerListener(drawerToggle)
        drawerToggle.syncState()

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, AllMatchesFragment())
                .commit()
        }

        navigationView.setNavigationItemSelectedListener { menuItem ->
            Log.d("MainActivity", "Navigation Item Selected: ${menuItem.title}")
            menuItem.isChecked = true  
            drawerLayout.closeDrawers() 

            when (menuItem.itemId) {
                R.id.nav_saved_matches -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragment_container, SavedMatchesFragment())
                        .commit()
                }
                R.id.nav_all_matches -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragment_container, AllMatchesFragment())
                        .commit()
                }
                else -> {
                    Log.d("MainActivity", "Unknown menu item clicked")
                }
            }
            return@setNavigationItemSelectedListener true
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == android.R.id.home) {
            Log.d("MainActivity", "Opening Drawer")
            if (!drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.openDrawer(GravityCompat.START)
            }
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
