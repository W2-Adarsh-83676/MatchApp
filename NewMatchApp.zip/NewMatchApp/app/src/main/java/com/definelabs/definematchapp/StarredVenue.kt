package com.definelabs.definematchapp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "starred_venues")
data class StarredVenue(
    @PrimaryKey val id: String,
    val name: String,
    val location: String,
    val isStarred: Boolean
)
