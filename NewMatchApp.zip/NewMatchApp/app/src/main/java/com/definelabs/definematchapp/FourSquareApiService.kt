package com.definelabs.definematchapp

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface FourSquareApiService {

    @GET("venues/search")
    fun getVenues(
        @Query("ll") ll: String,
        @Query("oauth_token") oauthToken: String,
        @Query("v") version: String
    ): Call<VenueResponse>
}
