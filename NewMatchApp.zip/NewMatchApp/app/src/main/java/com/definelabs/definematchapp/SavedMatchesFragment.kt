package com.definelabs.definematchapp

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SavedMatchesFragment : Fragment(R.layout.fragment_saved_matches) {

    private var recyclerView: RecyclerView? = null
    private lateinit var adapter: ApiVenueAdapter
    private lateinit var db: AppDatabase

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = (requireActivity().application as MyApplication).db

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView?.layoutManager = LinearLayoutManager(context)

        adapter = ApiVenueAdapter(mutableListOf()) { venue ->
            onStarClick(venue)
        }
        recyclerView?.adapter = adapter

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val savedVenues = db.starredVenueDao().getAllStarredVenues()
                val venueList = savedVenues.mapNotNull { starredVenue ->
                    val location = starredVenue.location?.let {
                        Location(address = it, city = "Unknown", country = "Unknown")
                    } ?: return@mapNotNull null 
                    Venue(
                        name = starredVenue.name,
                        location = location,
                        isStarred = true
                    )
                }
                CoroutineScope(Dispatchers.Main).launch {
                    if (venueList.isNotEmpty()) {
                        Log.d("SavedMatchesFragment", "Saved venues loaded: ${venueList.size}")
                        adapter.updateData(venueList)
                    } else {
                        Log.d("SavedMatchesFragment", "No venues found")
                    }
                }
            } catch (e: Exception) {
                Log.e("SavedMatchesFragment", "Error fetching venues: ${e.message}")
                e.printStackTrace()
            }
        }

    }

    private fun onStarClick(venue: Venue) {
        CoroutineScope(Dispatchers.IO).launch {
            if (venue.isStarred) {
                db.starredVenueDao().deleteStarredVenue(
                    StarredVenue(id = venue.name, name = venue.name, location = "${venue.location?.address}, ${venue.location?.city}", isStarred = false)
                )

                val position = adapter.venues.indexOfFirst { it.name == venue.name }
                if (position != -1) {
                    adapter.venues.removeAt(position)  
                    CoroutineScope(Dispatchers.Main).launch {
                        adapter.notifyItemRemoved(position) 
                    }
                }
            } else {
                db.starredVenueDao().insertStarredVenue(
                    StarredVenue(id = venue.name, name = venue.name, location = "${venue.location?.address}, ${venue.location?.city}", isStarred = true)
                )
            }

            venue.isStarred = !venue.isStarred

            CoroutineScope(Dispatchers.Main).launch {
                adapter.notifyDataSetChanged()
            }
        }
    }
}
