package com.definelabs.definematchapp


data class Venue(
    val name: String,
    val location: Location,
    var isStarred: Boolean = false
)
