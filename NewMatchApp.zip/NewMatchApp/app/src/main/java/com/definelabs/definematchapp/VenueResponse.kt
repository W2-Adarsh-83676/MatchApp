package com.definelabs.definematchapp
import com.definelabs.definematchapp.Venue
import com.google.gson.annotations.SerializedName


data class Location(
    @SerializedName("address") val address: String?,
    @SerializedName("city") val city: String?,
    @SerializedName("country") val country: String?
)

data class Icon(
    @SerializedName("prefix") val prefix: String,
    @SerializedName("suffix") val suffix: String
)


data class VenueResponse(
    @SerializedName("response") val response: VenueResponseBody
)

data class VenueResponseBody(
    @SerializedName("venues") val venues: List<Venue>
)
