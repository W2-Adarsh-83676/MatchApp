package com.definelabs.definematchapp

import android.app.Application
import androidx.room.Room

class MyApplication : Application() {
    val db by lazy { Room.databaseBuilder(this, AppDatabase::class.java, "app_database").build() }
}

