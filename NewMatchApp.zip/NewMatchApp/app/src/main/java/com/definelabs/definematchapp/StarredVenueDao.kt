package com.definelabs.definematchapp

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface StarredVenueDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) 
    suspend fun insertStarredVenue(starredVenue: StarredVenue)

    @Delete
    suspend fun deleteStarredVenue(starredVenue: StarredVenue)

    @Query("SELECT * FROM starred_venues")
    suspend fun getAllStarredVenues(): List<StarredVenue>

    @Query("SELECT * FROM starred_venues WHERE id = :id LIMIT 1")
    suspend fun getStarredVenueById(id: String): StarredVenue?
}

