package com.definelabs.definematchapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AllMatchesFragment : Fragment(R.layout.fragment_all_matches) {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ApiVenueAdapter
    private val repository = VenueRepository()
    private lateinit var db: AppDatabase

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = (requireActivity().application as MyApplication).db

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)
        adapter = ApiVenueAdapter(mutableListOf()) { venue ->

            if (!venue.isStarred) {
                val starredVenue = StarredVenue(
                    id = venue.name,
                    name = venue.name,
                    location = "${venue.location.address}, ${venue.location.city}",
                    isStarred = true
                )

                CoroutineScope(Dispatchers.IO).launch {
                    db.starredVenueDao().insertStarredVenue(starredVenue)
                }

                venue.isStarred = true
            } else {
                CoroutineScope(Dispatchers.IO).launch {
                    val starredVenueToDelete = StarredVenue(
                        id = venue.name,
                        name = venue.name,
                        location = "${venue.location.address}, ${venue.location.city}",
                        isStarred = false
                    )
                    db.starredVenueDao().deleteStarredVenue(starredVenueToDelete)
                }

                venue.isStarred = false
            }
            adapter.notifyDataSetChanged()
        }

        recyclerView.adapter = adapter

        repository.venueList.observe(viewLifecycleOwner, Observer { venues ->
            if (venues.isNotEmpty()) {
                Log.d("AllMatchesFragment", "Venues loaded: ${venues.size}")
                CoroutineScope(Dispatchers.IO).launch {
                    val starredVenues = db.starredVenueDao().getAllStarredVenues()

                    val updatedVenues = venues.map { venueApi ->
                        val isStarred = starredVenues.any { it.id == venueApi.name }
                        Venue(
                            name = venueApi.name,
                            location = Location(address = venueApi.location.address, city = "City", country = "Country"),
                            isStarred = isStarred  // Set based on local DB
                        )
                    }
                    CoroutineScope(Dispatchers.Main).launch {
                        adapter.updateData(updatedVenues)
                    }
                }
            } else {
                Log.d("AllMatchesFragment", "No venues found")
            }
        })

        repository.fetchVenues()
        Log.d("AllMatchesFragment", "Fetching venues...")
    }
}
