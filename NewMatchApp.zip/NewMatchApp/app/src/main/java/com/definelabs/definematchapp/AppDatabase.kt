package com.definelabs.definematchapp

import androidx.room.Database
import androidx.room.RoomDatabase


@Database(entities = [StarredVenue::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun starredVenueDao(): StarredVenueDao
}
