package com.definelabs.definematchapp


import android.util.Log
import androidx.lifecycle.MutableLiveData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class VenueRepository {

    val venueList: MutableLiveData<List<Venue>> = MutableLiveData()

    fun fetchVenues() {
        Log.d("VenueRepository", "Fetching venues...")

        val call = RetrofitInstance.apiService.getVenues(
            "40.7484,-73.9857", 
            "NPKYZ3WZ1VYMNAZ2FLX1WLECAWSMUVOQZOIDBN53F3LVZBPQ", 
            "20180616" 
        )

        call.enqueue(object : Callback<VenueResponse> {
            override fun onResponse(call: Call<VenueResponse>, response: Response<VenueResponse>) {
                if (response.isSuccessful) {
                    val venues = response.body()?.response?.venues ?: emptyList()
                    Log.d("VenueRepository", "Received ${venues.size} venues")
                    Log.d("VenueRepository", "Venues: ${venues.joinToString { it.name }}") 
                    venueList.postValue(venues)
                } else {
                    Log.e("VenueRepository", "API call failed: ${response.code()} ${response.message()}")
                    Log.e("VenueRepository", "Error body: ${response.errorBody()?.string()}")  
                }
            }

            override fun onFailure(call: Call<VenueResponse>, t: Throwable) {
                Log.e("VenueRepository", "API call failed: ${t.message}")
                t.printStackTrace() 
            }
        })
    }
}
