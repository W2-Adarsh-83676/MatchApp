package com.definelabs.definematchapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ApiVenueAdapter(
    var venues: MutableList<Venue>,
    private val onStarClick: (Venue) -> Unit
) : RecyclerView.Adapter<ApiVenueAdapter.VenueViewHolder>() {

    fun updateData(newVenues: List<Venue>) {
        venues.clear()
        venues.addAll(newVenues)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VenueViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_venue, parent, false)
        return VenueViewHolder(view)
    }

    override fun onBindViewHolder(holder: VenueViewHolder, position: Int) {
        val venue = venues[position]
        holder.bind(venue)
    }

    override fun getItemCount(): Int = venues.size

    inner class VenueViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val venueName = view.findViewById<TextView>(R.id.venueName)
        private val starIcon = view.findViewById<ImageView>(R.id.starIcon)

        fun bind(venue: Venue) {
            venueName.text = venue.name
            starIcon.setImageResource(
                if (venue.isStarred) R.drawable.ic_star_filled
                else R.drawable.ic_star_empty
            )

            starIcon.setOnClickListener {
                onStarClick(venue)
            }
        }
    }
}
