package com.definelabs.definematchapp.ui.view

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.definelabs.definematchapp.R
import com.definelabs.definematchapp.ui.adapter.ApiVenueAdapter
import com.definelabs.definematchapp.ui.viewmodel.VenueViewModel

class AllMatchesFragment : Fragment(R.layout.fragment_all_matches) {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ApiVenueAdapter
    private val viewModel: VenueViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)

        adapter = ApiVenueAdapter(mutableListOf()) { venue ->
            Log.d("AllMatchesFragment", "Toggling starred status for venue: ${venue.name}")

            viewModel.toggleStarredStatus(venue)
        }
        recyclerView.adapter = adapter

        viewModel.venues.observe(viewLifecycleOwner, Observer { venues ->
            if (venues!!.isNotEmpty()) {
                Log.d("AllMatchesFragment", "Venues loaded: ${venues.size}")
                adapter.updateData(venues)
            } else {
                Log.d("AllMatchesFragment", "No venues found")
            }
        })

        Log.d("AllMatchesFragment", "Fetching venues from API...")
        viewModel.fetchVenuesFromApi()

        viewModel.starredVenues.observe(viewLifecycleOwner, Observer { starredVenues ->
            Log.d("AllMatchesFragment", "Starred venues updated: ${starredVenues.size}")
            adapter.updateData(viewModel.venues.value ?: emptyList())
        })
    }
}
