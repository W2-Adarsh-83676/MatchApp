package com.definelabs.definematchapp.data.model

data class Meta(
    val code: Int,
    val errorType: String?,
    val errorDetail: String?
)