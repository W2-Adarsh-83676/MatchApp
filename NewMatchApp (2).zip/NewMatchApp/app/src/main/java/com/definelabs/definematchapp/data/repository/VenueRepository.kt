package com.definelabs.definematchapp.data.repository

import android.util.Log
import com.definelabs.definematchapp.data.model.Location
import com.definelabs.definematchapp.data.model.StarredVenue
import com.definelabs.definematchapp.data.model.Venue
import com.definelabs.definematchapp.data.room.AppDatabase
import com.definelabs.definematchapp.network.RetrofitInstance
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class VenueRepository(private val db: AppDatabase) {

    private val gson = Gson()

    suspend fun fetchVenues(): List<Venue> {
        return withContext(Dispatchers.IO) {
            try {
                val response = RetrofitInstance.apiService.getVenues(
                    "40.7484,-73.9857",
                    "NPKYZ3WZ1VYMNAZ2FLX1WLECAWSMUVOQZOIDBN53F3LVZBPQ",
                    "20180616"
                )

                if (response.isSuccessful) {
                    val venueResponse = response.body()
                    if (venueResponse?.response?.results != null) {
                        val venues = venueResponse.response.results
                        Log.d("VenueRepository", "Fetched ${venues.size} venues.")
                        venues
                    } else {
                        Log.e("VenueRepository", "API returned null results.")
                        emptyList()
                    }
                } else {
                    val errorBody = response.errorBody()?.string() ?: "Unknown error"
                    Log.e("VenueRepository", "API error: $errorBody, Code: ${response.code()}")
                    emptyList()
                }
            } catch (e: Exception) {
                Log.e("VenueRepository", "Exception fetching venues: ${e.message}")
                emptyList()
            }
        }
    }

    suspend fun isVenueStarred(venueName: String): Boolean {
        return try {
            Log.d("VenueRepository", "Checking if venue '$venueName' is starred.")
            val result = db.starredVenueDao().getStarredVenueByName(venueName) != null
            Log.d("VenueRepository", "Venue '$venueName' is starred: $result")
            result
        } catch (e: Exception) {
            Log.e("VenueRepository", "Error checking starred status for '$venueName': ${e.message}")
            false
        }
    }


    suspend fun addStarredVenue(venue: Venue) {
        try {
            Log.d("VenueRepository", "Adding venue '${venue.name}' to starred list.")

            db.starredVenueDao().insertStarredVenue(
                StarredVenue(venue.id, venue.name, venue.location, true)
            )
        } catch (e: Exception) {
            Log.e("VenueRepository", "Error adding venue '${venue.name}' to starred list: ${e.message}")
        }
    }

    suspend fun removeStarredVenue(venue: Venue) {
        try {
            Log.d("VenueRepository", "Removing venue '${venue.name}' from starred list.")

            val starredVenue = db.starredVenueDao().getStarredVenueByName(venue.name)
            starredVenue?.let {
                db.starredVenueDao().deleteStarredVenue(it)
            }
        } catch (e: Exception) {
            Log.e("VenueRepository", "Error removing venue '${venue.name}' from starred list: ${e.message}")
        }
    }

    suspend fun getStarredVenues(): List<Venue> {
        return withContext(Dispatchers.IO) {
            try {
                Log.d("VenueRepository", "Fetching all starred venues from database.")

                val starredVenues = db.starredVenueDao().getAllStarredVenues().map {
                    Venue(
                        it.id,
                        it.name,
                        it.location,
                        it.isStarred
                    )
                }

                Log.d("VenueRepository", "Found ${starredVenues.size} starred venues.")
                starredVenues
            } catch (e: Exception) {
                Log.e("VenueRepository", "Error fetching starred venues: ${e.message}")
                emptyList()
            }
        }
    }

}