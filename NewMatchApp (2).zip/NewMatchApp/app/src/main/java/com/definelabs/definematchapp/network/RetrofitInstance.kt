package com.definelabs.definematchapp.network

import com.definelabs.definematchapp.FourSquareApiService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitInstance {
    private const val BASE_URL = "https://api.foursquare.com"

    val apiService: FourSquareApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create()) // Ensure Gson converter is added
            .build()
            .create(FourSquareApiService::class.java)
    }
}
