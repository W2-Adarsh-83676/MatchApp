package com.definelabs.definematchapp.data.model
import com.google.gson.annotations.SerializedName

data class Location(
    val address: String?,
    val city: String?,
    val country: String?
)

data class Icon(
    @SerializedName("prefix") val prefix: String,
    @SerializedName("suffix") val suffix: String
)

data class VenueResponse(
    val meta: Meta,
    val response: ResponseData
)