package com.definelabs.definematchapp.data.model

import androidx.room.TypeConverter
import com.google.gson.Gson

class Converters {

    @TypeConverter
    fun fromLocation(location: Location?): String? {
        return location?.let { Gson().toJson(it) }
    }

    @TypeConverter
    fun toLocation(locationString: String?): Location? {
        return locationString?.let { Gson().fromJson(it, Location::class.java) }
    }
}
