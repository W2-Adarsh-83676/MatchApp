package com.definelabs.definematchapp.data.model

data class ResponseData(
    val results: List<Venue>?
)
