package com.definelabs.definematchapp.data.model


data class Venue(
    val id: String,
    val name: String,
    val location: Location,
    var isStarred: Boolean = false
)
