package com.definelabs.definematchapp.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.definelabs.definematchapp.R
import com.definelabs.definematchapp.data.model.Venue

class ApiVenueAdapter(
    private var venues: MutableList<Venue>,
    private val onStarClick: (Venue) -> Unit
) : RecyclerView.Adapter<ApiVenueAdapter.VenueViewHolder>() {

    fun updateData(newVenues: List<Venue>) {
        val diffCallback = VenueDiffCallback(venues, newVenues)
        val diffResult = DiffUtil.calculateDiff(diffCallback)

        venues.clear()
        venues.addAll(newVenues)
        diffResult.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VenueViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_venue, parent, false)
        return VenueViewHolder(view)
    }

    override fun onBindViewHolder(holder: VenueViewHolder, position: Int) {
        holder.bind(venues[position])
    }

    override fun getItemCount(): Int = venues.size

    inner class VenueViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val venueName: TextView = itemView.findViewById(R.id.venueName)
        private val venueAddress: TextView = itemView.findViewById(R.id.venueAddress)
        private val venueCity: TextView = itemView.findViewById(R.id.venueCity)
        private val venueCountry: TextView = itemView.findViewById(R.id.venueCountry)
        private val starIcon: ImageView = itemView.findViewById(R.id.starIcon)

        fun bind(venue: Venue) {
            venueName.text = venue.name
            venueAddress.text = venue.location.address ?: "Unknown Address"
            venueCity.text = venue.location.city ?: "Unknown City"
            venueCountry.text = venue.location.country ?: "Unknown Country"

            // Set the star icon based on whether the venue is starred
            starIcon.setImageResource(
                if (venue.isStarred) R.drawable.ic_star_filled
                else R.drawable.ic_star_empty
            )

            // Handle the star click event
            starIcon.setOnClickListener {
                onStarClick(venue)
            }
        }
    }

    class VenueDiffCallback(
        private val oldList: List<Venue>,
        private val newList: List<Venue>
    ) : DiffUtil.Callback() {
        override fun getOldListSize(): Int = oldList.size
        override fun getNewListSize(): Int = newList.size

        override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
            return oldList[oldItemPosition].id == newList[newItemPosition].id
        }

        override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
            return oldList[oldItemPosition] == newList[newItemPosition]
        }
    }
}
