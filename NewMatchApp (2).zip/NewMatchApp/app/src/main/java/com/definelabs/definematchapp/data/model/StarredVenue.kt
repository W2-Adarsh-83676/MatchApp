package com.definelabs.definematchapp.data.model

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "starred_venues")
data class StarredVenue(
    @PrimaryKey val id: String,
    val name: String,
    @Embedded val location: Location,
    val isStarred: Boolean
)