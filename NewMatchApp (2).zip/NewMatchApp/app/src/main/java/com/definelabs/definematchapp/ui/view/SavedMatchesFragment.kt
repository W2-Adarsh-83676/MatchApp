package com.definelabs.definematchapp.ui.view

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.definelabs.definematchapp.R
import com.definelabs.definematchapp.ui.adapter.ApiVenueAdapter
import com.definelabs.definematchapp.ui.viewmodel.VenueViewModel

class SavedMatchesFragment : Fragment(R.layout.fragment_saved_matches) {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ApiVenueAdapter
    private val viewModel: VenueViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)

        adapter = ApiVenueAdapter(mutableListOf()) { venue ->
            viewModel.toggleStarredStatus(venue)
        }
        recyclerView.adapter = adapter

        viewModel.starredVenues.observe(viewLifecycleOwner, Observer { starredVenues ->
            adapter.updateData(starredVenues)
        })
    }
}