package com.definelabs.definematchapp.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.definelabs.definematchapp.data.model.Venue
import com.definelabs.definematchapp.data.repository.VenueRepository
import com.definelabs.definematchapp.data.room.AppDatabase
import kotlinx.coroutines.launch

class VenueViewModel(application: Application) : AndroidViewModel(application) {

    private val _venues = MutableLiveData<List<Venue>?>()
    val venues: MutableLiveData<List<Venue>?> get() = _venues

    private val _starredVenues = MutableLiveData<List<Venue>>()
    val starredVenues: LiveData<List<Venue>> get() = _starredVenues

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> get() = _error

    private val repository: VenueRepository = VenueRepository(AppDatabase.getDatabase(application))

    init {
        loadStarredVenues()
    }

    fun fetchVenuesFromApi() {
        viewModelScope.launch {
            try {
                val apiVenues = repository.fetchVenues()

                val updatedVenues = apiVenues.map { venue ->
                    venue.copy(isStarred = repository.isVenueStarred(venue.name))
                }

                _venues.postValue(updatedVenues)
                _error.postValue(null) 
            } catch (e: Exception) {
                _error.postValue("Failed to fetch venues: ${e.message}")
            }
        }
    }

    private fun loadStarredVenues() {
        viewModelScope.launch {
            try {
                _starredVenues.value = repository.getStarredVenues()
                _error.postValue(null) 
            } catch (e: Exception) {
                _error.postValue("Failed to load starred venues: ${e.message}")
            }
        }
    }

    fun toggleStarredStatus(venue: Venue) {
        viewModelScope.launch {
            try {
                if (venue.isStarred) {
                    repository.removeStarredVenue(venue)
                } else {
                    repository.addStarredVenue(venue)
                }

                val updatedVenues = _venues.value?.map {
                    if (it.name == venue.name) it.copy(isStarred = !venue.isStarred) else it
                }
                _venues.value = updatedVenues

                loadStarredVenues()
            } catch (e: Exception) {
                _error.postValue("Failed to toggle starred status: ${e.message}")
            }
        }
    }
}