package com.definelabs.definematchapp.data.room
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.definelabs.definematchapp.data.model.StarredVenue

@Dao
interface StarredVenueDao {

    @Insert
    suspend fun insertStarredVenue(starredVenue: StarredVenue)

    @Delete
    suspend fun deleteStarredVenue(starredVenue: StarredVenue)

    @Query("SELECT * FROM starred_venues WHERE name = :venueName")
    suspend fun getStarredVenueByName(venueName: String): StarredVenue?

    @Query("SELECT * FROM starred_venues")
    suspend fun getAllStarredVenues(): List<StarredVenue>
}
