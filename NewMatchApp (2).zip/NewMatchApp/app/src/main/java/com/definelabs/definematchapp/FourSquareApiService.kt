package com.definelabs.definematchapp

import com.definelabs.definematchapp.data.model.VenueResponse
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface FourSquareApiService {
    @GET("/v2/venues/search")
    suspend fun getVenues(
        @Query("ll") ll: String,
        @Query("oauth_token") oauthToken: String,  
        @Query("v") version: String
    ): Response<VenueResponse>
}

