package com.definelabs.definematchapp

import android.app.Application
import androidx.room.Room
import com.definelabs.definematchapp.data.room.AppDatabase

class MyApplication : Application() {
    val db by lazy { Room.databaseBuilder(this, AppDatabase::class.java, "app_database").build() }
}

